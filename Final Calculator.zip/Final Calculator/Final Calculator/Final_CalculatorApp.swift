//
//  Final_CalculatorApp.swift
//  Final Calculator
//
//  Created by Alex Anderson on 9/27/22.
//

import SwiftUI

@main
struct Final_CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
